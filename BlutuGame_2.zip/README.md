# BlutuGamev2

The rewrite of BlutuGame

BlutuGame is a game made in JavaScript and Kaboom.JS

## Installation:

### Linux (Debian based Distros):
Open up your Terminal and type in following Command:

`sudo apt install git -y`

Now type in `git clone https://github.com/BlutudlutMC/BlutuGamev2.git && cd BlutuGamev2`
Make sure you have Liveserver with NPM installed!
Now type in `live-server` and a browser window is opening automatially!

### Windows:
Install Git from [here](https://github.com/git-for-windows/git/releases/download/v2.37.1.windows.1/Git-2.37.1-64-bit.exe).
Type in `git clone git clone https://github.com/BlutudlutMC/BlutuGamev2.git` and `cd BlutuGamev2` open it with live-server and done!
